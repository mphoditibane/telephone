export interface Settings {
    allowRegistration?: boolean;
}