// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyA1__BlhXadeLeGSYrp1wDUBazg_X7z16o',
    authDomain: 'clientsite-57cc6.firebaseapp.com',
    databaseURL: 'https://clientsite-57cc6.firebaseio.com',
    projectId: 'clientsite-57cc6',
    storageBucket: 'clientsite-57cc6.appspot.com',
    messagingSenderId: '684036519654'
  }

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
