export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyA1__BlhXadeLeGSYrp1wDUBazg_X7z16o',
    authDomain: 'clientsite-57cc6.firebaseapp.com',
    databaseURL: 'https://clientsite-57cc6.firebaseio.com',
    projectId: 'clientsite-57cc6',
    storageBucket: 'clientsite-57cc6.appspot.com',
    messagingSenderId: '684036519654'
  }
};
